//app.js
App({
  onLaunch: function () {

  },
  globalData: {
    userInfo: null,
    questionSort:null,
    questionType:null,
    questions: [],
    nice:"",
    url:"",
    gender:"",
    openid:"",
    id:""





  }
})