//app.js
App({

  onLaunch: function () {
  

  },
  globalData: {
    type: null,
    list:null,
    phone:null,
    openid:"",
    address:"", 
    isquit:false
  }
 
})