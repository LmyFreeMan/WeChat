var data = 'init data'
// 获取插件信息
function getPluginInfo() {
  return {
    name: 'dropdownmenu',
    version: '1.0.0',
    date: '2018-04-18',
    author: 'jetli'
  }
}
